console.log("jestem drugi");
